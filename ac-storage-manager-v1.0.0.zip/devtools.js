chrome.devtools.panels.create(
    "Storage Manager",
    "icons/icon16.png",
    "panel.html",
    function(panel) {
        console.log("Panel created");
    }
);
